#!/usr/bin/env python
# coding: utf-8

# In this version of script values from all the bands are included in the output profile. And not just "NIR" and "VIS" as it was in the _23m script.
# This is the script to gather output data from sequence.
# 
# 
# In the sequence we vary:
# 
# 
# * trees' position files (0_0.txt, 0_1.txt, ...)
# * scene type (0: "white", 1: "black" and 2: "natural")
# 
# We calculate albedo for each scene as well as absorbtion of trees and piece of scene under the tree for each species.

# In[1]:


SEQNAME = "h"
ntreesx = 10
ntreesy = 6
crownd = 5
height_sc = 19
number_of_bands = 43


# In[2]:


import os

path, DIRNAME = os.path.split(os.getcwd())
bands = [i for i in range(number_of_bands)]

os.system("mkdir " + DIRNAME + "_db")
os.system('sqlite3 -header -csv ./' + DIRNAME + '_' + SEQNAME + '.db "select * from Albedo;" > ' + './' + DIRNAME+ "_db" + '/Albedo.csv')
os.system('sqlite3 -header -csv ./' + DIRNAME + '_' + SEQNAME + '.db "select * from Combination;" > ' + './' + DIRNAME + "_db" + '/Combination.csv')
os.system('sqlite3 -header -csv ./' + DIRNAME + '_' + SEQNAME + '.db "select * from Simulation;" > ' + './' + DIRNAME + "_db" + '/Simulation.csv')
os.system('sqlite3 -header -csv ./' + DIRNAME + '_' + SEQNAME + '.db "select * from ScalarResult;" > ' + './' + DIRNAME + "_db" + '/ScalarResult.csv')


# In[3]:


def match(tab_from, tab_to, common_index, col_from, col_to):
    for i in tab_to[common_index].unique():
        index_tsc = tab_to[common_index] == i
        index_tcomb = tab_from[common_index] == i
        tab_to.loc[index_tsc, col_to] = tab_from[index_tcomb][col_from].values[0]
    return tab_to


# In[4]:


import numpy as np

def pertree_mean(tbl, ntreesxloc, ntreesyloc, crowndloc):
    
    res = [0]*ntreesxloc*ntreesyloc
    for y in range(ntreesyloc):
        for x in range(ntreesxloc):
            xstart = x*crowndloc
            ystart = y*crowndloc
            xsize = ntreesxloc*crownd
            
            tree_inds = [ list(range(xstart + xsize*k, xstart + xsize*k + crowndloc)) for k in range(ystart,ystart + crowndloc) ]
            tree_inds = [item for sublist in tree_inds for item in sublist]
            
            mean_tree_per_row = [np.mean([tbl[j][i] for i in tree_inds]) for j in range(len(tbl))]
            
            res[y*ntreesxloc + x] = mean_tree_per_row           
            
    return res


# In[5]:


import pandas as pd

talb = pd.read_csv("./" + DIRNAME + "_db/Albedo.csv")
tcomb = pd.read_csv("./" + DIRNAME + "_db/Combination.csv")
tsim = pd.read_csv("./" + DIRNAME + "_db/Simulation.csv")
tscalres = pd.read_csv("./" + DIRNAME + "_db/ScalarResult.csv")


# In[6]:


tscalres = tscalres[['idCombination', 'idSimulation', 'idSpectralBand']]
tscalres.columns = ['idCombination', 'idSimulation', 'band_num']


# In[7]:


tscalres['band'] = tscalres.band_num
#tscalres.loc[tscalres.band_num.isin( [i+1 for i in bands_nir] ), 'band'] = 'NIR'
#tscalres.loc[tscalres.band_num.isin( [i+1 for i in bands_vis] ), 'band'] = 'VIS'


# In[8]:


tscalres = match(tcomb, tscalres, 'idCombination', 'id_indexFctPhase', 'scenetype')
tscalres = match(tcomb, tscalres, 'idCombination', 'id_treePositionFileName', 'pos')
tscalres['albedo'] = talb.valueResult


# In[9]:


tscalres = tscalres.groupby(['idSimulation', 'scenetype', 'pos', 'band'], as_index=False)[['albedo']].mean()


# In[13]:


abs_list_bands = [0]*len(bands)

path_to_seq_file = "./sequence/" + "h" + "_" + "8" + "/output/BAND" +                                                    str(8) + "/RADIATIVE_BUDGET/ITERX/RadiativeBudget_3D"

with open(path_to_seq_file) as f:
    content = f.readlines()

content = [x.strip() for x in content] 
abs_list = [string.split(' ') for string in content]
start_index = [i for i in range(len(abs_list)) if abs_list[i][1] == "Absorbed"][0] + 1
abs_list = abs_list[start_index:]
height_sc = len(abs_list)
abs_list = np.array([ [float(row[i]) for i in range(len(row))] for row in abs_list])
#abs_list = np.array([abs_list[:-1].mean(axis = 0), abs_list[-1]])


# In[50]:


def abs_of_simulation (idSimulation_index): 
    
    sim_output = pd.DataFrame(columns=['idSimulation', 'band', 'num_of_species', 'species', 'height_m', 'abs_mean', 'abs_sd'])

    input_number = int(tscalres.loc[tscalres.idSimulation == idSimulation_index, 'pos'].mean()) - 1

    trees_sp = pd.read_csv("./input/0_" + str(input_number) + ".txt", sep = " ").SPECIES_ID

    sim_number = tsim.nameSimulation[tsim.idSimulation == idSimulation_index].values[0].split("_")[-1]

    ######################################################   BANDS  ###################################################### 

    abs_list_bands = [0]*len(bands)
    for band_number in bands:
        path_to_seq_file = "./sequence/" + SEQNAME + "_" + sim_number + "/output/BAND" +                                                            str(band_number) + "/RADIATIVE_BUDGET/ITERX/RadiativeBudget_3D"

        with open(path_to_seq_file) as f:
            content = f.readlines()

        content = [x.strip() for x in content] 
        abs_list = [string.split(' ') for string in content]
        start_index = [i for i in range(len(abs_list)) if abs_list[i][1] == "Absorbed"][0] + 1
        abs_list = abs_list[start_index:]
        height_sc = len(abs_list)
        abs_list = np.array([ [float(row[i]) for i in range(len(row))] for row in abs_list])
        #abs_list = np.array([abs_list[:-1].mean(axis = 0), abs_list[-1]])
        abs_list_bands[band_number] = abs_list

        #abs_BANDS = np.array(abs_list_bands).mean(axis=0)
        abs_per_tree = pertree_mean(abs_list, ntreesx, ntreesy, crownd)

        for sp_val in list(trees_sp.unique()):
            abs_sp_mean = pd.DataFrame(abs_per_tree)[trees_sp == sp_val].mean()
            abs_sp_sd = pd.DataFrame(abs_per_tree)[trees_sp == sp_val].std()
            for height in range(height_sc):
                sim_output = sim_output.append({'idSimulation': idSimulation_index, 'band': band_number,                                                 'num_of_species': len(trees_sp.unique()), 'species': sp_val,                                                 'height_m': height_sc - height,'abs_mean': abs_sp_mean[height],                                                 'abs_sd': abs_sp_sd[height]
                                               }, ignore_index=True)
    return sim_output


# In[52]:


import multiprocessing
from multiprocessing import Pool

num_cores = multiprocessing.cpu_count()

pool = Pool(num_cores)  
sim_output = pool.map(abs_of_simulation, tsim.idSimulation)
sim_output = pd.concat(sim_output, axis=0)


# In[62]:


sim_output["band"] = sim_output["band"].astype('int64', copy=False) + 1


# In[67]:


sim_output = match(tscalres, sim_output, 'idSimulation', 'pos', 'pos')
sim_output = match(tscalres, sim_output, 'idSimulation', 'scenetype', 'scenetype')


# In[68]:


for i,j in zip(tscalres['idSimulation'], tscalres['band']):
    index_tsc = (sim_output['idSimulation'] == i) & (sim_output['band'] == j)
    index_tcomb = (tscalres['idSimulation'] == i) & (tscalres['band'] == j)
    sim_output.loc[index_tsc, 'albedo'] = tscalres[index_tcomb]['albedo'].values


# In[69]:


sim_output["pos"] = sim_output['pos'].astype('int')
sim_output["scenetype"] = sim_output['scenetype'].astype('int')


# In[73]:


sim_output.to_csv("./profiles_" + DIRNAME + ".csv", index=False, index_label=False)


# In[63]:


sim_output.head(65)


# In[ ]:




