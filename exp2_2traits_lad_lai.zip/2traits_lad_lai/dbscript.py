import os

path, DIRNAME = os.path.split(os.getcwd())

os.system("mkdir " + DIRNAME)
os.system('sqlite3 -header -csv ./' + DIRNAME + '_h.db "select * from Albedo;" > ' + './' + DIRNAME + '/Albedo.csv')
os.system('sqlite3 -header -csv ./' + DIRNAME + '_h.db "select * from Combination;" > ' + './' + DIRNAME + '/Combination.csv')
